#include <stdio.h>

int main (){

// Pointer to function is the address of a function in the memory
// we can use pointers to call functions and to pass functions as arguments to other functions

// void (*ptr[3])(int)= {function1. function2, function3};
// Describe the above code!
// to assign in pointer ptr[3](array's adress) to a function returning an int 
// to assign function1. function2, function3 to "pointer to functions"
// mendaftarkan function1, function2, function3, 
// ke alamat arrays yang ditunjuk oleh pointer yakni *ptr[3]








    return 0;
}