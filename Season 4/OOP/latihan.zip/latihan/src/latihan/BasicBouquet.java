package latihan;

public class BasicBouquet {
	
	protected String flower;
	protected int price;
	
	public BasicBouquet(String flower, int price) {
		this.flower = flower;
		this.price = price;
	}
	
	public String getFlower() {
		return flower;
	}
	
	public void setFlower(String flower) {
		this.flower = flower;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	
	
	
}
