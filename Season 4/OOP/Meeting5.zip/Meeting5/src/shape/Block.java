package shape;


public class Block {
	double length;
	double width;
	double height;
	
	Block(double length, double width, double height){
		this.length = length;
		this.width = width;
		this.height = height;
	}
	
	double getVolume(){
		return length * width * height;
	}
	
	double getSurfaceArea(){
		return 2*(length*width + length*height + width*height);
	}
}
