
public interface Helm {
	
	public abstract void defense();
	public abstract void sundul();
	
	
}
