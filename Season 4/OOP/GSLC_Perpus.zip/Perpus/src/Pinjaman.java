
interface Pinjaman {
	void pinjamPustaka();
	void kembalikanPustaka();
}
