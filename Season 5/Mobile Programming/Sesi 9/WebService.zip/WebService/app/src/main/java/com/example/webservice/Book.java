package com.example.webservice;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class Book {
    @SerializedName("trackId")
    @Expose
    private Integer trackId;
    @SerializedName("trackName")
    @Expose
    String trackName;
    @SerializedName("artistIds")
    @Expose
    private List<Integer> artistIds;
    @SerializedName("artistId")
    @Expose
    private Integer artistId;
    @SerializedName("artistName")
    @Expose
    String artistName;
    @SerializedName("genres")
    @Expose
    private List<String> genres;
    @SerializedName("price")
    @Expose
    private Double price;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("currency")
    @Expose
    private String currency;
    @SerializedName("releaseDate")
    @Expose
    private String releaseDate;
    @SerializedName("artworkUrl100")
    @Expose
    private String artworkUrl100;
    @SerializedName("artistViewUrl")
    @Expose
    private String artistViewUrl;
    @SerializedName("artworkUrl60")
    @Expose
    String artworkUrl60;
    @SerializedName("trackViewUrl")
    @Expose
    private String trackViewUrl;
    @SerializedName("trackCensoredName")
    @Expose
    private String trackCensoredName;
    @SerializedName("fileSizeBytes")
    @Expose
    private Integer fileSizeBytes;
    @SerializedName("formattedPrice")
    @Expose
    private String formattedPrice;
    @SerializedName("genreIds")
    @Expose
    private List<String> genreIds;
    @SerializedName("kind")
    @Expose
    private String kind;
    @SerializedName("userRatingCount")
    @Expose
    private Integer userRatingCount;
    @SerializedName("averageUserRating")
    @Expose
    private Double averageUserRating;
}
