package com.example.webservice;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class BookResponse {
    @SerializedName("resultCount")
    @Expose
    Integer resultCount;
    @SerializedName("results")
    @Expose
    List<Book> results;
}
