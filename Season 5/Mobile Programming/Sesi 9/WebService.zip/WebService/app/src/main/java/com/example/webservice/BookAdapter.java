package com.example.webservice;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class BookAdapter extends RecyclerView.Adapter <BookAdapter.ViewHolder> {
    Context context;
    List <Book> listBook;

    BookAdapter(Context context){
        this.context = context;
        this.listBook = new ArrayList<>();
    }
    public void setListBook(List<Book> listBook){
        this.listBook = listBook;
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public BookAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_book,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookAdapter.ViewHolder holder, int position) {
        Book book = listBook.get(position);
        Glide.with(context).load(book.artworkUrl60).into(holder.image);
        holder.desc.setText(book.trackName +"\n"+ book.artistName);
    }

    @Override
    public int getItemCount() {
        return listBook.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView image;
        TextView desc;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.images);
            desc = itemView.findViewById(R.id.description);
        }
    }
}
