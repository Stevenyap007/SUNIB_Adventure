package com.example.webservice;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {

    RecyclerView rvBook;
    BookAdapter adapter;
    List<Book> listBook;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvBook = findViewById(R.id.rvBook);
        adapter = new BookAdapter(this);
        rvBook.setLayoutManager(new LinearLayoutManager(this));
        rvBook.setAdapter(adapter);

        Retrofit retrofit = APIClient.getRetrofit();
        ITunesServiceInterface service = retrofit.create(ITunesServiceInterface.class);
        Call<BookResponse> call = service.getBooks("ebook","computer");
        call.enqueue(new Callback<BookResponse>() {
            @Override
            public void onResponse(Call<BookResponse> call, Response<BookResponse> response) {
                listBook = response.body().results;
                adapter.setListBook(listBook);
            }

            @Override
            public void onFailure(Call<BookResponse> call, Throwable t) {

            }
        });
    }
}